import { Property } from '@/types/property';

export const mockProperties: Property[] = [
  {
    id: '1',
    title: 'Modern Downtown Apartment',
    description: 'Beautiful modern apartment in the heart of downtown with stunning city views. Recently renovated with high-end finishes and appliances.',
    price: 2500,
    location: {
      address: '123 Main Street',
      city: 'San Francisco',
      state: 'CA',
      zipCode: '94102',
      coordinates: { lat: 37.7749, lng: -122.4194 }
    },
    images: [
      'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg',
      'https://images.pexels.com/photos/2103127/pexels-photo-2103127.jpeg',
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg'
    ],
    propertyType: 'apartment',
    bedrooms: 2,
    bathrooms: 2,
    area: 1200,
    amenities: ['Pool', 'Gym', 'Parking', 'Laundry', 'Air Conditioning'],
    available: true,
    availableFrom: '2024-02-01',
    owner: {
      id: 'owner1',
      name: 'Bob Smith',
      phone: '+1 (555) 123-4567',
      email: 'bob.smith@example.com'
    },
    features: {
      furnished: false,
      parking: true,
      petFriendly: false,
      utilities: true
    },
    createdAt: '2024-01-15',
    updatedAt: '2024-01-15'
  },
  {
    id: '2',
    title: 'Cozy Studio in Historic District',
    description: 'Charming studio apartment in historic district. Perfect for young professionals or students. Walking distance to cafes and public transport.',
    price: 1800,
    location: {
      address: '456 Oak Avenue',
      city: 'Boston',
      state: 'MA',
      zipCode: '02101',
      coordinates: { lat: 42.3601, lng: -71.0589 }
    },
    images: [
      'https://images.pexels.com/photos/2724749/pexels-photo-2724749.jpeg',
      'https://images.pexels.com/photos/1457842/pexels-photo-1457842.jpeg'
    ],
    propertyType: 'studio',
    bedrooms: 0,
    bathrooms: 1,
    area: 600,
    amenities: ['Laundry', 'Internet', 'Heating'],
    available: true,
    availableFrom: '2024-01-20',
    owner: {
      id: 'owner2',
      name: 'Sarah Johnson',
      phone: '+1 (555) 234-5678',
      email: 'sarah.j@example.com'
    },
    features: {
      furnished: true,
      parking: false,
      petFriendly: true,
      utilities: false
    },
    createdAt: '2024-01-10',
    updatedAt: '2024-01-10'
  },
  {
    id: '3',
    title: 'Spacious Family House',
    description: 'Large family home with beautiful garden and quiet neighborhood. Perfect for families with children. Near good schools and parks.',
    price: 3200,
    location: {
      address: '789 Elm Street',
      city: 'Austin',
      state: 'TX',
      zipCode: '73301',
      coordinates: { lat: 30.2672, lng: -97.7431 }
    },
    images: [
      'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg',
      'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg',
      'https://images.pexels.com/photos/1029599/pexels-photo-1029599.jpeg'
    ],
    propertyType: 'house',
    bedrooms: 4,
    bathrooms: 3,
    area: 2400,
    amenities: ['Garden', 'Garage', 'Fireplace', 'Central Air', 'Security System'],
    available: true,
    availableFrom: '2024-02-15',
    owner: {
      id: 'owner3',
      name: 'Michael Davis',
      phone: '+1 (555) 345-6789',
      email: 'michael.davis@example.com'
    },
    features: {
      furnished: false,
      parking: true,
      petFriendly: true,
      utilities: false
    },
    createdAt: '2024-01-12',
    updatedAt: '2024-01-12'
  },
  {
    id: '4',
    title: 'Luxury Penthouse',
    description: 'Stunning penthouse with panoramic city views. Premium finishes, private elevator access, and rooftop terrace.',
    price: 5500,
    location: {
      address: '321 Skyline Drive',
      city: 'Miami',
      state: 'FL',
      zipCode: '33101',
      coordinates: { lat: 25.7617, lng: -80.1918 }
    },
    images: [
      'https://images.pexels.com/photos/1571468/pexels-photo-1571468.jpeg',
      'https://images.pexels.com/photos/2598300/pexels-photo-2598300.jpeg'
    ],
    propertyType: 'condo',
    bedrooms: 3,
    bathrooms: 3,
    area: 2000,
    amenities: ['Pool', 'Gym', 'Concierge', 'Valet Parking', 'Rooftop Deck'],
    available: true,
    availableFrom: '2024-03-01',
    owner: {
      id: 'owner4',
      name: 'Emma Wilson',
      phone: '+1 (555) 456-7890',
      email: 'emma.wilson@example.com'
    },
    features: {
      furnished: true,
      parking: true,
      petFriendly: false,
      utilities: true
    },
    createdAt: '2024-01-08',
    updatedAt: '2024-01-08'
  }
];

export const mockMessages = [
  {
    id: '1',
    propertyId: '1',
    propertyTitle: 'Modern Downtown Apartment',
    otherUser: 'Bob Smith',
    lastMessage: 'Thank you for your interest! When would you like to schedule a viewing?',
    timestamp: '2024-01-16T10:30:00Z',
    unread: true,
    messages: [
      {
        id: 'm1',
        sender: 'user',
        message: 'Hi, I\'m interested in your downtown apartment. Is it still available?',
        timestamp: '2024-01-16T09:00:00Z'
      },
      {
        id: 'm2',
        sender: 'other',
        message: 'Yes, it\'s still available! Would you like to know more details?',
        timestamp: '2024-01-16T09:15:00Z'
      },
      {
        id: 'm3',
        sender: 'user',
        message: 'Yes, I\'d love to schedule a viewing. What times work for you?',
        timestamp: '2024-01-16T10:00:00Z'
      },
      {
        id: 'm4',
        sender: 'other',
        message: 'Thank you for your interest! When would you like to schedule a viewing?',
        timestamp: '2024-01-16T10:30:00Z'
      }
    ]
  },
  {
    id: '2',
    propertyId: '2',
    propertyTitle: 'Cozy Studio in Historic District',
    otherUser: 'Sarah Johnson',
    lastMessage: 'Perfect! I can show you the place tomorrow at 2 PM.',
    timestamp: '2024-01-15T14:20:00Z',
    unread: false,
    messages: [
      {
        id: 'm5',
        sender: 'user',
        message: 'Is the studio pet-friendly?',
        timestamp: '2024-01-15T13:00:00Z'
      },
      {
        id: 'm6',
        sender: 'other',
        message: 'Yes, small pets are welcome! There\'s a pet deposit of $200.',
        timestamp: '2024-01-15T13:30:00Z'
      },
      {
        id: 'm7',
        sender: 'user',
        message: 'Great! Can I schedule a viewing?',
        timestamp: '2024-01-15T14:00:00Z'
      },
      {
        id: 'm8',
        sender: 'other',
        message: 'Perfect! I can show you the place tomorrow at 2 PM.',
        timestamp: '2024-01-15T14:20:00Z'
      }
    ]
  }
];