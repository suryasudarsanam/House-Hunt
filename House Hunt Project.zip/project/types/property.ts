export interface Property {
  id: string;
  title: string;
  description: string;
  price: number;
  location: {
    address: string;
    city: string;
    state: string;
    zipCode: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  images: string[];
  propertyType: 'apartment' | 'house' | 'condo' | 'room' | 'studio';
  bedrooms: number;
  bathrooms: number;
  area: number; // in sq ft
  amenities: string[];
  available: boolean;
  availableFrom: string;
  owner: {
    id: string;
    name: string;
    phone: string;
    email: string;
    avatar?: string;
  };
  features: {
    furnished: boolean;
    parking: boolean;
    petFriendly: boolean;
    utilities: boolean;
  };
  createdAt: string;
  updatedAt: string;
}

export interface PropertyFilters {
  priceRange: [number, number];
  propertyType?: string;
  bedrooms?: number;
  bathrooms?: number;
  location?: string;
  amenities?: string[];
  furnished?: boolean;
  parking?: boolean;
  petFriendly?: boolean;
}