import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plus, CreditCard as Edit, Trash2, Eye, Calendar, DollarSign } from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { mockProperties } from '@/data/mockData';
import { Property } from '@/types/property';

export default function PropertiesScreen() {
  const { user } = useAuth();
  const [showAddProperty, setShowAddProperty] = useState(false);
  const [properties, setProperties] = useState<Property[]>(
    mockProperties.filter(p => p.owner.id === 'owner1') // Show properties for current owner
  );

  const [newProperty, setNewProperty] = useState({
    title: '',
    description: '',
    price: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    propertyType: 'apartment',
    bedrooms: 1,
    bathrooms: 1,
    area: '',
  });

  // Only show this screen for owners
  if (user?.role !== 'owner') {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.unauthorizedContainer}>
          <Text style={styles.unauthorizedText}>
            This section is only available for property owners.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  const addProperty = () => {
    if (!newProperty.title || !newProperty.price || !newProperty.address) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    const property: Property = {
      id: Date.now().toString(),
      title: newProperty.title,
      description: newProperty.description,
      price: parseInt(newProperty.price),
      location: {
        address: newProperty.address,
        city: newProperty.city,
        state: newProperty.state,
        zipCode: newProperty.zipCode,
      },
      images: ['https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg'],
      propertyType: newProperty.propertyType as any,
      bedrooms: newProperty.bedrooms,
      bathrooms: newProperty.bathrooms,
      area: parseInt(newProperty.area) || 0,
      amenities: [],
      available: true,
      availableFrom: new Date().toISOString().split('T')[0],
      owner: {
        id: user?.id || '',
        name: user?.name || '',
        phone: user?.phone || '',
        email: user?.email || '',
      },
      features: {
        furnished: false,
        parking: false,
        petFriendly: false,
        utilities: false,
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setProperties([...properties, property]);
    setShowAddProperty(false);
    
    // Reset form
    setNewProperty({
      title: '',
      description: '',
      price: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      propertyType: 'apartment',
      bedrooms: 1,
      bathrooms: 1,
      area: '',
    });

    Alert.alert('Success', 'Property added successfully!');
  };

  const deleteProperty = (propertyId: string) => {
    Alert.alert(
      'Delete Property',
      'Are you sure you want to delete this property?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            setProperties(properties.filter(p => p.id !== propertyId));
          },
        },
      ]
    );
  };

  const toggleAvailability = (propertyId: string) => {
    setProperties(properties.map(p =>
      p.id === propertyId ? { ...p, available: !p.available } : p
    ));
  };

  const renderPropertyCard = (property: Property) => (
    <View key={property.id} style={styles.propertyCard}>
      <View style={styles.propertyHeader}>
        <View style={styles.propertyTitleContainer}>
          <Text style={styles.propertyTitle} numberOfLines={2}>
            {property.title}
          </Text>
          <View style={[
            styles.statusBadge,
            property.available ? styles.availableBadge : styles.unavailableBadge
          ]}>
            <Text style={[
              styles.statusText,
              property.available ? styles.availableText : styles.unavailableText
            ]}>
              {property.available ? 'Available' : 'Occupied'}
            </Text>
          </View>
        </View>
      </View>

      <Text style={styles.propertyLocation}>
        {property.location.address}, {property.location.city}
      </Text>

      <View style={styles.propertyDetails}>
        <View style={styles.detailItem}>
          <DollarSign size={16} color="#14B8A6" />
          <Text style={styles.detailText}>${property.price}/month</Text>
        </View>
        
        <View style={styles.detailItem}>
          <Calendar size={16} color="#6B7280" />
          <Text style={styles.detailText}>
            {property.bedrooms === 0 ? 'Studio' : `${property.bedrooms} bed`}
          </Text>
        </View>
        
        <View style={styles.detailItem}>
          <Eye size={16} color="#6B7280" />
          <Text style={styles.detailText}>{property.bathrooms} bath</Text>
        </View>
      </View>

      <View style={styles.propertyActions}>
        <TouchableOpacity
          style={[
            styles.actionButton,
            styles.toggleButton,
            property.available ? styles.occupyButton : styles.availableButton
          ]}
          onPress={() => toggleAvailability(property.id)}
        >
          <Text style={[
            styles.actionButtonText,
            property.available ? styles.occupyButtonText : styles.availableButtonText
          ]}>
            {property.available ? 'Mark Occupied' : 'Mark Available'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.iconButton}>
          <Edit size={20} color="#6B7280" />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.iconButton}
          onPress={() => deleteProperty(property.id)}
        >
          <Trash2 size={20} color="#EF4444" />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Properties</Text>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => setShowAddProperty(true)}
        >
          <Plus size={20} color="#FFFFFF" />
          <Text style={styles.addButtonText}>Add Property</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{properties.length}</Text>
          <Text style={styles.statLabel}>Total Properties</Text>
        </View>
        
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>
            {properties.filter(p => p.available).length}
          </Text>
          <Text style={styles.statLabel}>Available</Text>
        </View>
        
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>
            {properties.filter(p => !p.available).length}
          </Text>
          <Text style={styles.statLabel}>Occupied</Text>
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {properties.length > 0 ? (
          properties.map(renderPropertyCard)
        ) : (
          <View style={styles.emptyState}>
            <Plus size={48} color="#D1D5DB" />
            <Text style={styles.emptyStateTitle}>No properties yet</Text>
            <Text style={styles.emptyStateText}>
              Add your first property to start managing your rentals
            </Text>
            <TouchableOpacity
              style={styles.emptyStateButton}
              onPress={() => setShowAddProperty(true)}
            >
              <Text style={styles.emptyStateButtonText}>Add Property</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>

      <Modal
        visible={showAddProperty}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setShowAddProperty(false)}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Add Property</Text>
            <TouchableOpacity onPress={addProperty}>
              <Text style={styles.saveText}>Save</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            <View style={styles.formGroup}>
              <Text style={styles.label}>Property Title *</Text>
              <TextInput
                style={styles.input}
                value={newProperty.title}
                onChangeText={(text) => setNewProperty({...newProperty, title: text})}
                placeholder="Enter property title"
                placeholderTextColor="#9CA3AF"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Description</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={newProperty.description}
                onChangeText={(text) => setNewProperty({...newProperty, description: text})}
                placeholder="Describe your property"
                placeholderTextColor="#9CA3AF"
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.formRow}>
              <View style={styles.formGroupHalf}>
                <Text style={styles.label}>Monthly Rent *</Text>
                <TextInput
                  style={styles.input}
                  value={newProperty.price}
                  onChangeText={(text) => setNewProperty({...newProperty, price: text})}
                  placeholder="0"
                  placeholderTextColor="#9CA3AF"
                  keyboardType="numeric"
                />
              </View>

              <View style={styles.formGroupHalf}>
                <Text style={styles.label}>Area (sq ft)</Text>
                <TextInput
                  style={styles.input}
                  value={newProperty.area}
                  onChangeText={(text) => setNewProperty({...newProperty, area: text})}
                  placeholder="0"
                  placeholderTextColor="#9CA3AF"
                  keyboardType="numeric"
                />
              </View>
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Address *</Text>
              <TextInput
                style={styles.input}
                value={newProperty.address}
                onChangeText={(text) => setNewProperty({...newProperty, address: text})}
                placeholder="Street address"
                placeholderTextColor="#9CA3AF"
              />
            </View>

            <View style={styles.formRow}>
              <View style={styles.formGroupHalf}>
                <Text style={styles.label}>City</Text>
                <TextInput
                  style={styles.input}
                  value={newProperty.city}
                  onChangeText={(text) => setNewProperty({...newProperty, city: text})}
                  placeholder="City"
                  placeholderTextColor="#9CA3AF"
                />
              </View>

              <View style={styles.formGroupQuarter}>
                <Text style={styles.label}>State</Text>
                <TextInput
                  style={styles.input}
                  value={newProperty.state}
                  onChangeText={(text) => setNewProperty({...newProperty, state: text})}
                  placeholder="ST"
                  placeholderTextColor="#9CA3AF"
                />
              </View>

              <View style={styles.formGroupQuarter}>
                <Text style={styles.label}>ZIP</Text>
                <TextInput
                  style={styles.input}
                  value={newProperty.zipCode}
                  onChangeText={(text) => setNewProperty({...newProperty, zipCode: text})}
                  placeholder="12345"
                  placeholderTextColor="#9CA3AF"
                  keyboardType="numeric"
                />
              </View>
            </View>

            <View style={styles.formRow}>
              <View style={styles.formGroupThird}>
                <Text style={styles.label}>Bedrooms</Text>
                <View style={styles.numberSelector}>
                  <TouchableOpacity
                    style={styles.numberButton}
                    onPress={() => setNewProperty({
                      ...newProperty,
                      bedrooms: Math.max(0, newProperty.bedrooms - 1)
                    })}
                  >
                    <Text style={styles.numberButtonText}>−</Text>
                  </TouchableOpacity>
                  <Text style={styles.numberValue}>{newProperty.bedrooms}</Text>
                  <TouchableOpacity
                    style={styles.numberButton}
                    onPress={() => setNewProperty({
                      ...newProperty,
                      bedrooms: newProperty.bedrooms + 1
                    })}
                  >
                    <Text style={styles.numberButtonText}>+</Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.formGroupThird}>
                <Text style={styles.label}>Bathrooms</Text>
                <View style={styles.numberSelector}>
                  <TouchableOpacity
                    style={styles.numberButton}
                    onPress={() => setNewProperty({
                      ...newProperty,
                      bathrooms: Math.max(1, newProperty.bathrooms - 1)
                    })}
                  >
                    <Text style={styles.numberButtonText}>−</Text>
                  </TouchableOpacity>
                  <Text style={styles.numberValue}>{newProperty.bathrooms}</Text>
                  <TouchableOpacity
                    style={styles.numberButton}
                    onPress={() => setNewProperty({
                      ...newProperty,
                      bathrooms: newProperty.bathrooms + 1
                    })}
                  >
                    <Text style={styles.numberButtonText}>+</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#111827',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#14B8A6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 8,
  },
  addButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 16,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statNumber: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#14B8A6',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  propertyCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  propertyHeader: {
    marginBottom: 8,
  },
  propertyTitleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 4,
  },
  propertyTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    flex: 1,
    marginRight: 12,
    lineHeight: 24,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  availableBadge: {
    backgroundColor: '#ECFDF5',
  },
  unavailableBadge: {
    backgroundColor: '#FEF2F2',
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
  availableText: {
    color: '#10B981',
  },
  unavailableText: {
    color: '#EF4444',
  },
  propertyLocation: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 12,
  },
  propertyDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#374151',
  },
  propertyActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  toggleButton: {
    borderWidth: 1,
  },
  occupyButton: {
    backgroundColor: '#FEF2F2',
    borderColor: '#FECACA',
  },
  availableButton: {
    backgroundColor: '#ECFDF5',
    borderColor: '#A7F3D0',
  },
  actionButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  occupyButtonText: {
    color: '#DC2626',
  },
  availableButtonText: {
    color: '#059669',
  },
  iconButton: {
    width: 36,
    height: 36,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F3F4F6',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
    paddingHorizontal: 32,
  },
  emptyStateTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  emptyStateButton: {
    backgroundColor: '#14B8A6',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  emptyStateButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  unauthorizedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },
  unauthorizedText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
  },
  cancelText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  saveText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#14B8A6',
  },
  modalContent: {
    flex: 1,
    padding: 16,
  },
  formGroup: {
    marginBottom: 20,
  },
  formRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  formGroupHalf: {
    flex: 1,
  },
  formGroupThird: {
    flex: 1,
  },
  formGroupQuarter: {
    width: 80,
  },
  label: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#111827',
    backgroundColor: '#FFFFFF',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  numberSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
  },
  numberButton: {
    width: 40,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  numberButtonText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  numberValue: {
    flex: 1,
    textAlign: 'center',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
  },
});