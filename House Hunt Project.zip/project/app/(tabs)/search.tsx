import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Filter, X, MapPin, Chrome as Home, Bed, Bath } from 'lucide-react-native';
import { PropertyFilters } from '@/types/property';
import { mockProperties } from '@/data/mockData';

const propertyTypes = [
  { id: 'all', label: 'All Types' },
  { id: 'apartment', label: 'Apartment' },
  { id: 'house', label: 'House' },
  { id: 'condo', label: 'Condo' },
  { id: 'studio', label: 'Studio' },
  { id: 'room', label: 'Room' },
];

const bedroomOptions = [
  { id: 'any', label: 'Any', value: undefined },
  { id: '0', label: 'Studio', value: 0 },
  { id: '1', label: '1+', value: 1 },
  { id: '2', label: '2+', value: 2 },
  { id: '3', label: '3+', value: 3 },
  { id: '4', label: '4+', value: 4 },
];

const bathroomOptions = [
  { id: 'any', label: 'Any', value: undefined },
  { id: '1', label: '1+', value: 1 },
  { id: '2', label: '2+', value: 2 },
  { id: '3', label: '3+', value: 3 },
];

const commonAmenities = [
  'Pool', 'Gym', 'Parking', 'Laundry', 'Air Conditioning',
  'Heating', 'Internet', 'Garden', 'Balcony', 'Security'
];

export default function SearchScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<PropertyFilters>({
    priceRange: [500, 6000],
    propertyType: 'all',
    bedrooms: undefined,
    bathrooms: undefined,
    amenities: [],
    furnished: undefined,
    parking: undefined,
    petFriendly: undefined,
  });

  const [tempFilters, setTempFilters] = useState<PropertyFilters>(filters);

  const applyFilters = () => {
    setFilters(tempFilters);
    setShowFilters(false);
  };

  const resetFilters = () => {
    const defaultFilters: PropertyFilters = {
      priceRange: [500, 6000],
      propertyType: 'all',
      bedrooms: undefined,
      bathrooms: undefined,
      amenities: [],
      furnished: undefined,
      parking: undefined,
      petFriendly: undefined,
    };
    setTempFilters(defaultFilters);
    setFilters(defaultFilters);
  };

  const getFilteredProperties = () => {
    return mockProperties.filter(property => {
      // Search query filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesSearch = 
          property.title.toLowerCase().includes(query) ||
          property.location.city.toLowerCase().includes(query) ||
          property.location.address.toLowerCase().includes(query) ||
          property.description.toLowerCase().includes(query);
        
        if (!matchesSearch) return false;
      }

      // Price range filter
      if (property.price < filters.priceRange[0] || property.price > filters.priceRange[1]) {
        return false;
      }

      // Property type filter
      if (filters.propertyType && filters.propertyType !== 'all' && property.propertyType !== filters.propertyType) {
        return false;
      }

      // Bedrooms filter
      if (filters.bedrooms !== undefined && property.bedrooms < filters.bedrooms) {
        return false;
      }

      // Bathrooms filter
      if (filters.bathrooms !== undefined && property.bathrooms < filters.bathrooms) {
        return false;
      }

      // Amenities filter
      if (filters.amenities && filters.amenities.length > 0) {
        const hasAllAmenities = filters.amenities.every(amenity =>
          property.amenities.includes(amenity)
        );
        if (!hasAllAmenities) return false;
      }

      // Features filter
      if (filters.furnished !== undefined && property.features.furnished !== filters.furnished) {
        return false;
      }

      if (filters.parking !== undefined && property.features.parking !== filters.parking) {
        return false;
      }

      if (filters.petFriendly !== undefined && property.features.petFriendly !== filters.petFriendly) {
        return false;
      }

      return true;
    });
  };

  const filteredProperties = getFilteredProperties();

  const toggleAmenity = (amenity: string) => {
    setTempFilters(prev => ({
      ...prev,
      amenities: prev.amenities?.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...(prev.amenities || []), amenity]
    }));
  };

  const activeFiltersCount = Object.values(filters).filter(value => {
    if (Array.isArray(value)) return value.length > 0;
    if (typeof value === 'boolean') return true;
    if (value === undefined || value === 'all') return false;
    if (Array.isArray(filters.priceRange) && value === filters.priceRange) {
      return !(filters.priceRange[0] === 500 && filters.priceRange[1] === 6000);
    }
    return true;
  }).length;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Search Properties</Text>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Search size={20} color="#6B7280" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search by location, type, or keywords..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#9CA3AF"
          />
        </View>
        <TouchableOpacity
          style={[styles.filterButton, activeFiltersCount > 0 && styles.filterButtonActive]}
          onPress={() => setShowFilters(true)}
        >
          <Filter size={20} color={activeFiltersCount > 0 ? '#FFFFFF' : '#14B8A6'} />
          {activeFiltersCount > 0 && (
            <View style={styles.filterBadge}>
              <Text style={styles.filterBadgeText}>{activeFiltersCount}</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.resultsHeader}>
        <Text style={styles.resultsText}>
          {filteredProperties.length} properties found
        </Text>
      </View>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {filteredProperties.map(property => (
          <TouchableOpacity key={property.id} style={styles.propertyCard}>
            <View style={styles.propertyInfo}>
              <Text style={styles.propertyTitle} numberOfLines={2}>
                {property.title}
              </Text>
              
              <View style={styles.locationRow}>
                <MapPin size={14} color="#6B7280" />
                <Text style={styles.locationText} numberOfLines={1}>
                  {property.location.address}, {property.location.city}
                </Text>
              </View>
              
              <View style={styles.detailsRow}>
                <View style={styles.detailItem}>
                  <Home size={16} color="#6B7280" />
                  <Text style={styles.detailText}>{property.propertyType}</Text>
                </View>
                
                <View style={styles.detailItem}>
                  <Bed size={16} color="#6B7280" />
                  <Text style={styles.detailText}>
                    {property.bedrooms === 0 ? 'Studio' : `${property.bedrooms} bed`}
                  </Text>
                </View>
                
                <View style={styles.detailItem}>
                  <Bath size={16} color="#6B7280" />
                  <Text style={styles.detailText}>{property.bathrooms} bath</Text>
                </View>
              </View>
              
              <Text style={styles.priceText}>${property.price}/month</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Modal
        visible={showFilters}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setShowFilters(false)}>
              <X size={24} color="#6B7280" />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Filters</Text>
            <TouchableOpacity onPress={resetFilters}>
              <Text style={styles.resetText}>Reset</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            {/* Property Type */}
            <View style={styles.filterSection}>
              <Text style={styles.filterLabel}>Property Type</Text>
              <View style={styles.optionsGrid}>
                {propertyTypes.map(type => (
                  <TouchableOpacity
                    key={type.id}
                    style={[
                      styles.optionButton,
                      tempFilters.propertyType === type.id && styles.optionButtonActive
                    ]}
                    onPress={() => setTempFilters(prev => ({ ...prev, propertyType: type.id }))}
                  >
                    <Text style={[
                      styles.optionText,
                      tempFilters.propertyType === type.id && styles.optionTextActive
                    ]}>
                      {type.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Bedrooms */}
            <View style={styles.filterSection}>
              <Text style={styles.filterLabel}>Bedrooms</Text>
              <View style={styles.optionsRow}>
                {bedroomOptions.map(option => (
                  <TouchableOpacity
                    key={option.id}
                    style={[
                      styles.optionButton,
                      tempFilters.bedrooms === option.value && styles.optionButtonActive
                    ]}
                    onPress={() => setTempFilters(prev => ({ ...prev, bedrooms: option.value }))}
                  >
                    <Text style={[
                      styles.optionText,
                      tempFilters.bedrooms === option.value && styles.optionTextActive
                    ]}>
                      {option.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Bathrooms */}
            <View style={styles.filterSection}>
              <Text style={styles.filterLabel}>Bathrooms</Text>
              <View style={styles.optionsRow}>
                {bathroomOptions.map(option => (
                  <TouchableOpacity
                    key={option.id}
                    style={[
                      styles.optionButton,
                      tempFilters.bathrooms === option.value && styles.optionButtonActive
                    ]}
                    onPress={() => setTempFilters(prev => ({ ...prev, bathrooms: option.value }))}
                  >
                    <Text style={[
                      styles.optionText,
                      tempFilters.bathrooms === option.value && styles.optionTextActive
                    ]}>
                      {option.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Amenities */}
            <View style={styles.filterSection}>
              <Text style={styles.filterLabel}>Amenities</Text>
              <View style={styles.optionsGrid}>
                {commonAmenities.map(amenity => (
                  <TouchableOpacity
                    key={amenity}
                    style={[
                      styles.optionButton,
                      tempFilters.amenities?.includes(amenity) && styles.optionButtonActive
                    ]}
                    onPress={() => toggleAmenity(amenity)}
                  >
                    <Text style={[
                      styles.optionText,
                      tempFilters.amenities?.includes(amenity) && styles.optionTextActive
                    ]}>
                      {amenity}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Features */}
            <View style={styles.filterSection}>
              <Text style={styles.filterLabel}>Features</Text>
              <View style={styles.featureToggles}>
                <TouchableOpacity
                  style={[
                    styles.featureToggle,
                    tempFilters.furnished === true && styles.featureToggleActive
                  ]}
                  onPress={() => setTempFilters(prev => ({
                    ...prev,
                    furnished: prev.furnished === true ? undefined : true
                  }))}
                >
                  <Text style={[
                    styles.featureToggleText,
                    tempFilters.furnished === true && styles.featureToggleTextActive
                  ]}>
                    Furnished
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.featureToggle,
                    tempFilters.parking === true && styles.featureToggleActive
                  ]}
                  onPress={() => setTempFilters(prev => ({
                    ...prev,
                    parking: prev.parking === true ? undefined : true
                  }))}
                >
                  <Text style={[
                    styles.featureToggleText,
                    tempFilters.parking === true && styles.featureToggleTextActive
                  ]}>
                    Parking
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.featureToggle,
                    tempFilters.petFriendly === true && styles.featureToggleActive
                  ]}
                  onPress={() => setTempFilters(prev => ({
                    ...prev,
                    petFriendly: prev.petFriendly === true ? undefined : true
                  }))}
                >
                  <Text style={[
                    styles.featureToggleText,
                    tempFilters.petFriendly === true && styles.featureToggleTextActive
                  ]}>
                    Pet Friendly
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>

          <View style={styles.modalFooter}>
            <TouchableOpacity style={styles.applyButton} onPress={applyFilters}>
              <Text style={styles.applyButtonText}>Apply Filters</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#111827',
  },
  searchContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    gap: 12,
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    paddingHorizontal: 16,
    height: 48,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#111827',
  },
  filterButton: {
    width: 48,
    height: 48,
    backgroundColor: '#ECFDF5',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#14B8A6',
    position: 'relative',
  },
  filterButtonActive: {
    backgroundColor: '#14B8A6',
    borderColor: '#14B8A6',
  },
  filterBadge: {
    position: 'absolute',
    top: -6,
    right: -6,
    backgroundColor: '#EF4444',
    borderRadius: 10,
    width: 20,
    height: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  filterBadgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontFamily: 'Inter-Bold',
  },
  resultsHeader: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  resultsText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  propertyCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  propertyInfo: {
    gap: 8,
  },
  propertyTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    lineHeight: 24,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  locationText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    flex: 1,
  },
  detailsRow: {
    flexDirection: 'row',
    gap: 16,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#374151',
  },
  priceText: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#14B8A6',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
  },
  resetText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#14B8A6',
  },
  modalContent: {
    flex: 1,
    padding: 16,
  },
  filterSection: {
    marginBottom: 32,
  },
  filterLabel: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginBottom: 16,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  optionsRow: {
    flexDirection: 'row',
    gap: 8,
  },
  optionButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  optionButtonActive: {
    backgroundColor: '#14B8A6',
    borderColor: '#14B8A6',
  },
  optionText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  optionTextActive: {
    color: '#FFFFFF',
  },
  featureToggles: {
    gap: 12,
  },
  featureToggle: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  featureToggleActive: {
    backgroundColor: '#14B8A6',
    borderColor: '#14B8A6',
  },
  featureToggleText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  featureToggleTextActive: {
    color: '#FFFFFF',
  },
  modalFooter: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  applyButton: {
    backgroundColor: '#14B8A6',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  applyButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
});