import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Users, Building, MessageSquare, CircleCheck as CheckCircle, Circle as XCircle, Eye } from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';

interface PendingUser {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'renter';
  phone?: string;
  registeredAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

interface PlatformStats {
  totalUsers: number;
  totalProperties: number;
  totalMessages: number;
  pendingApprovals: number;
  activeRentals: number;
}

export default function AdminScreen() {
  const { user } = useAuth();
  
  const [stats] = useState<PlatformStats>({
    totalUsers: 1247,
    totalProperties: 342,
    totalMessages: 8951,
    pendingApprovals: 12,
    activeRentals: 89,
  });

  const [pendingUsers, setPendingUsers] = useState<PendingUser[]>([
    {
      id: '1',
      name: 'John Smith',
      email: 'john.smith@example.com',
      role: 'owner',
      phone: '+1 (555) 123-4567',
      registeredAt: '2024-01-15T10:30:00Z',
      status: 'pending',
    },
    {
      id: '2',
      name: 'Sarah Davis',
      email: 'sarah.davis@example.com',
      role: 'owner',
      phone: '+1 (555) 234-5678',
      registeredAt: '2024-01-16T14:20:00Z',
      status: 'pending',
    },
    {
      id: '3',
      name: 'Mike Johnson',
      email: 'mike.johnson@example.com',
      role: 'renter',
      registeredAt: '2024-01-16T16:45:00Z',
      status: 'pending',
    },
  ]);

  // Only show this screen for admins
  if (user?.role !== 'admin') {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.unauthorizedContainer}>
          <Text style={styles.unauthorizedText}>
            This section is only available for administrators.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  const handleUserAction = (userId: string, action: 'approve' | 'reject') => {
    const user = pendingUsers.find(u => u.id === userId);
    if (!user) return;

    const actionText = action === 'approve' ? 'approve' : 'reject';
    
    Alert.alert(
      `${action === 'approve' ? 'Approve' : 'Reject'} User`,
      `Are you sure you want to ${actionText} ${user.name}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: action === 'approve' ? 'Approve' : 'Reject',
          style: action === 'approve' ? 'default' : 'destructive',
          onPress: () => {
            setPendingUsers(users =>
              users.map(u =>
                u.id === userId
                  ? { ...u, status: action === 'approve' ? 'approved' : 'rejected' }
                  : u
              )
            );
            
            Alert.alert(
              'Success',
              `User ${action === 'approve' ? 'approved' : 'rejected'} successfully!`
            );
          },
        },
      ]
    );
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString([], {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const renderStatsCard = (icon: any, title: string, value: number, color: string) => {
    const IconComponent = icon;
    return (
      <View style={styles.statsCard}>
        <View style={[styles.statsIcon, { backgroundColor: `${color}20` }]}>
          <IconComponent size={24} color={color} />
        </View>
        <View style={styles.statsContent}>
          <Text style={styles.statsValue}>{value.toLocaleString()}</Text>
          <Text style={styles.statsTitle}>{title}</Text>
        </View>
      </View>
    );
  };

  const renderPendingUserCard = (pendingUser: PendingUser) => (
    <View key={pendingUser.id} style={styles.userCard}>
      <View style={styles.userInfo}>
        <View style={styles.userHeader}>
          <Text style={styles.userName}>{pendingUser.name}</Text>
          <View style={[
            styles.roleBadge,
            pendingUser.role === 'owner' ? styles.ownerBadge : styles.renterBadge
          ]}>
            <Text style={[
              styles.roleText,
              pendingUser.role === 'owner' ? styles.ownerText : styles.renterText
            ]}>
              {pendingUser.role === 'owner' ? 'Owner' : 'Renter'}
            </Text>
          </View>
        </View>
        
        <Text style={styles.userEmail}>{pendingUser.email}</Text>
        {pendingUser.phone && (
          <Text style={styles.userPhone}>{pendingUser.phone}</Text>
        )}
        
        <Text style={styles.registrationDate}>
          Registered: {formatDate(pendingUser.registeredAt)}
        </Text>
      </View>

      {pendingUser.status === 'pending' && (
        <View style={styles.userActions}>
          <TouchableOpacity
            style={styles.approveButton}
            onPress={() => handleUserAction(pendingUser.id, 'approve')}
          >
            <CheckCircle size={16} color="#FFFFFF" />
            <Text style={styles.approveButtonText}>Approve</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.rejectButton}
            onPress={() => handleUserAction(pendingUser.id, 'reject')}
          >
            <XCircle size={16} color="#FFFFFF" />
            <Text style={styles.rejectButtonText}>Reject</Text>
          </TouchableOpacity>
        </View>
      )}

      {pendingUser.status !== 'pending' && (
        <View style={styles.statusContainer}>
          <Text style={[
            styles.statusText,
            pendingUser.status === 'approved' ? styles.approvedStatus : styles.rejectedStatus
          ]}>
            {pendingUser.status === 'approved' ? 'Approved' : 'Rejected'}
          </Text>
        </View>
      )}
    </View>
  );

  const pendingCount = pendingUsers.filter(u => u.status === 'pending').length;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Admin Dashboard</Text>
        <Text style={styles.subtitle}>Platform Overview & Management</Text>
      </View>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Platform Statistics */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Platform Statistics</Text>
          <View style={styles.statsGrid}>
            {renderStatsCard(Users, 'Total Users', stats.totalUsers, '#3B82F6')}
            {renderStatsCard(Building, 'Properties', stats.totalProperties, '#14B8A6')}
            {renderStatsCard(MessageSquare, 'Messages', stats.totalMessages, '#F59E0B')}
            {renderStatsCard(Eye, 'Active Rentals', stats.activeRentals, '#10B981')}
          </View>
        </View>

        {/* Pending Approvals */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Pending User Approvals</Text>
            {pendingCount > 0 && (
              <View style={styles.pendingBadge}>
                <Text style={styles.pendingBadgeText}>{pendingCount}</Text>
              </View>
            )}
          </View>
          
          {pendingUsers.length > 0 ? (
            <View style={styles.usersList}>
              {pendingUsers.map(renderPendingUserCard)}
            </View>
          ) : (
            <View style={styles.emptyState}>
              <CheckCircle size={48} color="#D1D5DB" />
              <Text style={styles.emptyStateTitle}>All caught up!</Text>
              <Text style={styles.emptyStateText}>
                There are no pending user approvals at the moment.
              </Text>
            </View>
          )}
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionsGrid}>
            <TouchableOpacity style={styles.actionCard}>
              <Users size={24} color="#3B82F6" />
              <Text style={styles.actionTitle}>Manage Users</Text>
              <Text style={styles.actionDescription}>View and manage all platform users</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionCard}>
              <Building size={24} color="#14B8A6" />
              <Text style={styles.actionTitle}>Review Properties</Text>
              <Text style={styles.actionDescription}>Monitor property listings and compliance</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionCard}>
              <MessageSquare size={24} color="#F59E0B" />
              <Text style={styles.actionTitle}>Platform Messages</Text>
              <Text style={styles.actionDescription}>Oversee communication and disputes</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 24,
  },
  section: {
    gap: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
  },
  pendingBadge: {
    backgroundColor: '#EF4444',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    minWidth: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pendingBadgeText: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  statsGrid: {
    gap: 12,
  },
  statsCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statsIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  statsContent: {
    flex: 1,
  },
  statsValue: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginBottom: 4,
  },
  statsTitle: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  usersList: {
    gap: 12,
  },
  userCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  userInfo: {
    marginBottom: 16,
  },
  userHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  userName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    flex: 1,
    marginRight: 12,
  },
  roleBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  ownerBadge: {
    backgroundColor: '#EEF2FF',
  },
  renterBadge: {
    backgroundColor: '#F0FDF4',
  },
  roleText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
  ownerText: {
    color: '#3730A3',
  },
  renterText: {
    color: '#166534',
  },
  userEmail: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 4,
  },
  userPhone: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 8,
  },
  registrationDate: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#9CA3AF',
  },
  userActions: {
    flexDirection: 'row',
    gap: 8,
  },
  approveButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#10B981',
    paddingVertical: 10,
    borderRadius: 8,
    gap: 6,
  },
  approveButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  rejectButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#EF4444',
    paddingVertical: 10,
    borderRadius: 8,
    gap: 6,
  },
  rejectButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  statusContainer: {
    alignItems: 'center',
  },
  statusText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  approvedStatus: {
    color: '#10B981',
  },
  rejectedStatus: {
    color: '#EF4444',
  },
  actionsGrid: {
    gap: 12,
  },
  actionCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  actionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#111827',
    marginTop: 8,
    marginBottom: 4,
  },
  actionDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 20,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyStateTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 20,
  },
  unauthorizedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },
  unauthorizedText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
  },
});