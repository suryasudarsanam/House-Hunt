import { Tabs } from 'expo-router';
import { Chrome as Home, Search, MessageCircle, User, Building, Settings } from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';

export default function TabLayout() {
  const { user } = useAuth();

  const getTabsForRole = () => {
    const baseTabs = [
      {
        name: 'index',
        title: 'Home',
        icon: Home,
      },
      {
        name: 'search',
        title: 'Search',
        icon: Search,
      },
      {
        name: 'messages',
        title: 'Messages',
        icon: MessageCircle,
      },
      {
        name: 'profile',
        title: 'Profile',
        icon: User,
      },
    ];

    if (user?.role === 'owner') {
      baseTabs.splice(3, 0, {
        name: 'properties',
        title: 'Properties',
        icon: Building,
      });
    }

    if (user?.role === 'admin') {
      baseTabs.splice(3, 0, {
        name: 'admin',
        title: 'Admin',
        icon: Settings,
      });
    }

    return baseTabs;
  };

  const tabs = getTabsForRole();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: '#14B8A6',
        tabBarInactiveTintColor: '#6B7280',
        tabBarStyle: {
          backgroundColor: '#FFFFFF',
          borderTopWidth: 1,
          borderTopColor: '#E5E7EB',
          paddingTop: 8,
          paddingBottom: 8,
          height: 68,
        },
        tabBarLabelStyle: {
          fontFamily: 'Inter-Medium',
          fontSize: 12,
          marginTop: 4,
        },
      }}
    >
      {tabs.map((tab) => (
        <Tabs.Screen
          key={tab.name}
          name={tab.name}
          options={{
            title: tab.title,
            tabBarIcon: ({ size, color }) => (
              <tab.icon size={size} color={color} strokeWidth={2} />
            ),
          }}
        />
      ))}
    </Tabs>
  );
}